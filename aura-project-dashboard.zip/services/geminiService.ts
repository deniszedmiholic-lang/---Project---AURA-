import { GoogleGenAI } from "@google/genai";

// FIX: Removed API key mocking logic to adhere to the guideline of exclusively using process.env.API_KEY.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const runAuraAiChat = async (prompt: string): Promise<string> => {
    // FIX: Removed mock response logic and updated the API call to align with Gemini API best practices.
    // This includes using `systemInstruction` for the persona prompt and adding `thinkingConfig`
    // because `maxOutputTokens` is set for a `gemini-2.5-flash` model.
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: "You are AURA, an AI project assistant. Be helpful, insightful, and slightly futuristic.",
                temperature: 0.7,
                topP: 1,
                topK: 1,
                maxOutputTokens: 256,
                thinkingConfig: { thinkingBudget: 128 },
            }
        });
        return response.text;
    } catch (error) {
        console.error("Gemini API error:", error);
        return "I seem to be having trouble connecting to my core systems. Please try again in a moment.";
    }
};
