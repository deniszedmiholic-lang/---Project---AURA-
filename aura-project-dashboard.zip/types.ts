// FIX: Import React to provide the React namespace for the React.ReactNode type used below.
import React from 'react';

export interface Task {
  id: string;
  title: string;
  dueDate: string;
  completed: boolean;
}

export interface TeamMember {
  id: string;
  name: string;
  avatarUrl: string;
  role: string;
}

export interface ChartDataPoint {
  name: string;
  completed: number;
  pending: number;
}

export interface NavLink {
    name: string;
    icon: React.ReactNode;
}