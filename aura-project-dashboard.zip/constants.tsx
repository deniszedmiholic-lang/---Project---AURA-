
import React from 'react';
import type { Task, TeamMember, ChartDataPoint, NavLink } from './types';
import { Home, CheckSquare, BarChart2, Users, Settings } from 'lucide-react';

export const NAV_LINKS: NavLink[] = [
  { name: 'Home', icon: <Home size={20} /> },
  { name: 'Tasks', icon: <CheckSquare size={20} /> },
  { name: 'Analytics', icon: <BarChart2 size={20} /> },
  { name: 'Team', icon: <Users size={20} /> },
  { name: 'Settings', icon: <Settings size={20} /> },
];

export const MOCK_TASKS: Task[] = [
  { id: '1', title: 'Design the new landing page', dueDate: '2024-08-15', completed: false },
  { id: '2', title: 'Develop authentication flow', dueDate: '2024-08-18', completed: false },
  { id: '3', title: 'Setup CI/CD pipeline', dueDate: '2024-08-20', completed: true },
  { id: '4', title: 'Write API documentation', dueDate: '2024-08-22', completed: false },
  { id: '5', title: 'User acceptance testing', dueDate: '2024-08-25', completed: false },
];

export const MOCK_TEAM_MEMBERS: TeamMember[] = [
  { id: '1', name: 'Alina Petrova', avatarUrl: 'https://picsum.photos/id/1027/100/100', role: 'Project Manager' },
  { id: '2', name: 'Ben Carter', avatarUrl: 'https://picsum.photos/id/1005/100/100', role: 'Lead Developer' },
  { id: '3', name: 'Carla Rodriguez', avatarUrl: 'https://picsum.photos/id/1011/100/100', role: 'UX/UI Designer' },
  { id: '4', name: 'David Chen', avatarUrl: 'https://picsum.photos/id/1012/100/100', role: 'Frontend Dev' },
];

export const MOCK_CHART_DATA: ChartDataPoint[] = [
  { name: 'Jan', completed: 30, pending: 20 },
  { name: 'Feb', completed: 45, pending: 25 },
  { name: 'Mar', completed: 60, pending: 30 },
  { name: 'Apr', completed: 55, pending: 35 },
  { name: 'May', completed: 75, pending: 15 },
  { name: 'Jun', completed: 80, pending: 10 },
];
