
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { MOCK_CHART_DATA } from '../constants';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-aura-surface p-3 rounded-lg border border-gray-700 shadow-lg">
        <p className="label font-bold text-white">{`${label}`}</p>
        <p className="text-aura-secondary">{`Completed: ${payload[0].value}`}</p>
        <p className="text-aura-accent">{`Pending: ${payload[1].value}`}</p>
      </div>
    );
  }
  return null;
};

const ProgressChart: React.FC = () => {
  return (
    <div className="bg-aura-surface p-6 rounded-2xl border border-gray-800 h-[420px]">
      <h3 className="text-xl font-bold text-white mb-4">Task Progress (Last 6 Months)</h3>
      <ResponsiveContainer width="100%" height="90%">
        <BarChart
          data={MOCK_CHART_DATA}
          margin={{
            top: 5,
            right: 20,
            left: -10,
            bottom: 5,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
          <XAxis dataKey="name" stroke="#A0A0A0" fontSize={12} />
          <YAxis stroke="#A0A0A0" fontSize={12} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(138, 43, 226, 0.1)' }} />
          <Legend wrapperStyle={{fontSize: "14px"}}/>
          <Bar dataKey="completed" fill="#40E0D0" name="Completed" radius={[4, 4, 0, 0]} />
          <Bar dataKey="pending" fill="#FF00FF" name="Pending" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ProgressChart;
