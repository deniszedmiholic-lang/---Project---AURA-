
import React from 'react';
import { MoreVertical } from './icons';

interface ProjectOverviewCardProps {
  title: string;
  value: string;
  change: string;
  icon?: React.ReactNode;
  isNegative?: boolean;
}

const ProjectOverviewCard: React.FC<ProjectOverviewCardProps> = ({ title, value, change, icon, isNegative = false }) => {
  const changeColor = isNegative ? 'text-red-400' : 'text-green-400';

  return (
    <div className="bg-aura-surface p-6 rounded-2xl border border-gray-800/80 transition-all duration-300 hover:border-aura-primary/50 hover:shadow-lg hover:shadow-aura-primary/10">
      <div className="flex justify-between items-start">
        <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-aura-primary/10">
          {icon || <div className="w-6 h-6 bg-aura-secondary rounded-sm"></div>}
        </div>
        <button className="text-aura-text-secondary hover:text-white">
            <MoreVertical size={20} />
        </button>
      </div>
      <div className="mt-4">
        <p className="text-aura-text-secondary text-sm">{title}</p>
        <div className="flex items-baseline gap-2 mt-1">
          <h3 className="text-3xl font-bold text-white">{value}</h3>
          <span className={`text-sm font-semibold ${changeColor}`}>{change}</span>
        </div>
      </div>
    </div>
  );
};

export default ProjectOverviewCard;
