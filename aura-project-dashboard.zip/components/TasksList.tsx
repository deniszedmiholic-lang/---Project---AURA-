
import React, { useState } from 'react';
import { MOCK_TASKS } from '../constants';
import type { Task } from '../types';
import { PlusCircle, MoreVertical } from './icons';

const TaskItem: React.FC<{ task: Task, onToggle: (id: string) => void }> = ({ task, onToggle }) => (
    <div className="flex items-center justify-between p-3 hover:bg-aura-primary/10 rounded-lg transition-colors duration-200">
        <div className="flex items-center gap-3">
        <input
            type="checkbox"
            checked={task.completed}
            onChange={() => onToggle(task.id)}
            className="h-5 w-5 rounded bg-aura-surface border-gray-600 text-aura-secondary focus:ring-aura-secondary"
        />
        <div>
            <p className={`font-medium ${task.completed ? 'line-through text-aura-text-secondary' : 'text-white'}`}>{task.title}</p>
            <p className="text-xs text-aura-text-secondary">{task.dueDate}</p>
        </div>
        </div>
         <button className="text-aura-text-secondary hover:text-white">
            <MoreVertical size={20} />
        </button>
    </div>
);


const TasksList: React.FC = () => {
    const [tasks, setTasks] = useState(MOCK_TASKS);

    const handleToggleTask = (id: string) => {
        setTasks(currentTasks => 
            currentTasks.map(task => 
                task.id === id ? { ...task, completed: !task.completed } : task
            )
        );
    };

  return (
    <div className="bg-aura-surface p-6 rounded-2xl border border-gray-800 h-full">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-white">Active Tasks</h3>
        <button className="flex items-center gap-2 text-aura-secondary hover:text-white font-medium transition-colors duration-300">
            <PlusCircle size={20} />
            <span>New Task</span>
        </button>
      </div>
      <div className="space-y-2 max-h-[300px] overflow-y-auto pr-2">
        {tasks.map((task) => (
          <TaskItem key={task.id} task={task} onToggle={handleToggleTask} />
        ))}
      </div>
    </div>
  );
};

export default TasksList;
