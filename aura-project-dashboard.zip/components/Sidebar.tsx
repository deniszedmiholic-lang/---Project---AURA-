
import React from 'react';
import { Bot, Home } from './icons';
import { NAV_LINKS } from '../constants';

interface SidebarProps {
  onOpenAiChat: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onOpenAiChat }) => {
  const [activeLink, setActiveLink] = React.useState('Home');

  return (
    <aside className="w-64 bg-aura-surface flex flex-col p-4 border-r border-gray-800">
      <div className="flex items-center gap-3 px-2 mb-10">
        <div className="w-10 h-10 bg-gradient-to-br from-aura-primary to-aura-secondary rounded-lg flex items-center justify-center">
            <Home className="text-white" />
        </div>
        <h1 className="text-2xl font-bold text-white tracking-wider">AURA</h1>
      </div>

      <nav className="flex-1">
        <ul>
          {NAV_LINKS.map((link) => (
            <li key={link.name} className="mb-2">
              <a
                href="#"
                onClick={() => setActiveLink(link.name)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-300 ${
                  activeLink === link.name
                    ? 'bg-aura-primary/20 text-aura-secondary'
                    : 'text-aura-text-secondary hover:bg-gray-800/50 hover:text-white'
                }`}
              >
                {link.icon}
                <span className="font-medium">{link.name}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>

      <div className="mt-auto">
        <button
          onClick={onOpenAiChat}
          className="w-full flex items-center justify-center gap-3 px-4 py-3 rounded-lg bg-gradient-to-r from-aura-primary to-aura-accent text-white font-semibold hover:opacity-90 transition-opacity duration-300 shadow-lg shadow-aura-primary/20"
        >
          <Bot size={20} />
          <span>Chat with AURA</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
