
import React from 'react';
import { MOCK_TEAM_MEMBERS } from '../constants';
import type { TeamMember } from '../types';

const TeamMemberCard: React.FC<{ member: TeamMember }> = ({ member }) => (
    <div className="bg-aura-surface p-4 rounded-xl border border-gray-800 flex items-center gap-4 transition-all duration-300 hover:border-aura-secondary/50 hover:-translate-y-1">
        <img src={member.avatarUrl} alt={member.name} className="w-14 h-14 rounded-full" />
        <div>
            <h4 className="font-semibold text-white">{member.name}</h4>
            <p className="text-aura-text-secondary text-sm">{member.role}</p>
        </div>
    </div>
);

const TeamMembers: React.FC = () => {
  return (
    <div className="bg-aura-surface p-6 rounded-2xl border border-gray-800">
      <h3 className="text-xl font-bold text-white mb-4">Team Members</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {MOCK_TEAM_MEMBERS.map((member) => (
          <TeamMemberCard key={member.id} member={member} />
        ))}
      </div>
    </div>
  );
};

export default TeamMembers;
