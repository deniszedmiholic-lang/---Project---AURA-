
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, Loader } from './icons';
import { runAuraAiChat } from '../services/geminiService';

interface Message {
  sender: 'user' | 'aura';
  text: string;
}

interface AuraAiChatProps {
  isOpen: boolean;
  onClose: () => void;
}

const AuraAiChat: React.FC<AuraAiChatProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    if (isOpen) {
      setMessages([
        { sender: 'aura', text: "Hello! I'm AURA, your project assistant. How can I help you optimize your workflow today?" }
      ]);
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (input.trim() === '' || isLoading) return;

    const userMessage: Message = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const responseText = await runAuraAiChat(input);
      const auraMessage: Message = { sender: 'aura', text: responseText };
      setMessages(prev => [...prev, auraMessage]);
    } catch (error) {
      const errorMessage: Message = { sender: 'aura', text: 'Sorry, I am unable to process your request at the moment.' };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-aura-surface w-full max-w-2xl h-[80vh] rounded-2xl border border-gray-800 flex flex-col shadow-2xl shadow-aura-primary/20">
        <header className="flex items-center justify-between p-4 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <Bot className="text-aura-secondary" size={24} />
            <h2 className="text-xl font-bold text-white">AURA AI Assistant</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-aura-text-secondary hover:bg-gray-700 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </header>

        <main className="flex-1 p-6 overflow-y-auto space-y-6">
          {messages.map((msg, index) => (
            <div key={index} className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              {msg.sender === 'aura' && <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-aura-primary to-aura-secondary rounded-full flex items-center justify-center"><Bot size={18} className="text-white"/></div>}
              <div className={`max-w-md p-3 rounded-2xl ${msg.sender === 'user' ? 'bg-aura-primary text-white rounded-br-none' : 'bg-gray-800 text-aura-text rounded-bl-none'}`}>
                <p className="text-sm">{msg.text}</p>
              </div>
            </div>
          ))}
          {isLoading && (
             <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-aura-primary to-aura-secondary rounded-full flex items-center justify-center"><Bot size={18} className="text-white"/></div>
                <div className="max-w-md p-3 rounded-2xl bg-gray-800 text-aura-text rounded-bl-none flex items-center">
                    <Loader className="animate-spin text-aura-secondary" size={20} />
                </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </main>

        <footer className="p-4 border-t border-gray-800">
          <div className="flex items-center gap-3 bg-aura-background rounded-lg p-1 border border-gray-700 focus-within:ring-2 focus-within:ring-aura-primary transition-all">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Ask AURA anything..."
              className="flex-1 bg-transparent px-3 py-2 text-aura-text placeholder-aura-text-secondary focus:outline-none"
              disabled={isLoading}
            />
            <button
              onClick={handleSend}
              disabled={isLoading}
              className="p-2 rounded-md bg-aura-secondary text-aura-background disabled:bg-gray-600 disabled:cursor-not-allowed hover:opacity-90 transition-opacity"
            >
              <Send size={20} />
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default AuraAiChat;
