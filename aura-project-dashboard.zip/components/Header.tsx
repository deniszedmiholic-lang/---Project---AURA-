
import React from 'react';
import { Search, Bell, ChevronDown } from './icons';

const Header: React.FC = () => {
  return (
    <header className="flex-shrink-0 h-20 bg-aura-surface/50 backdrop-blur-sm flex items-center justify-between px-6 lg:px-8 border-b border-gray-800">
      <div className="relative w-full max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-aura-text-secondary" size={20} />
        <input
          type="text"
          placeholder="Search tasks, projects..."
          className="w-full bg-aura-surface border border-gray-700 rounded-lg pl-10 pr-4 py-2 text-aura-text focus:outline-none focus:ring-2 focus:ring-aura-primary transition-all"
        />
      </div>
      <div className="flex items-center gap-4">
        <button className="text-aura-text-secondary hover:text-white transition-colors">
          <Bell size={22} />
        </button>
        <div className="flex items-center gap-3">
          <img
            src="https://picsum.photos/id/1027/100/100"
            alt="User Avatar"
            className="w-10 h-10 rounded-full border-2 border-aura-secondary"
          />
          <div>
            <p className="font-semibold text-white">Alina Petrova</p>
            <p className="text-xs text-aura-text-secondary">Project Manager</p>
          </div>
           <button className="text-aura-text-secondary hover:text-white transition-colors">
            <ChevronDown size={20} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
