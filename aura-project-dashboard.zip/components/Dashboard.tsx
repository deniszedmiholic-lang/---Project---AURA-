
import React from 'react';
import ProjectOverviewCard from './ProjectOverviewCard';
import TasksList from './TasksList';
import TeamMembers from './TeamMembers';
import ProgressChart from './ProgressChart';
import { BarChart2, CheckSquare, Users } from './icons';

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8">
       <div>
        <h2 className="text-3xl font-bold text-white">Dashboard</h2>
        <p className="text-aura-text-secondary mt-1">Welcome back, here's your project overview.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <ProjectOverviewCard title="Active Projects" value="12" change="+5.2%" icon={<BarChart2 className="text-aura-secondary" />} />
        <ProjectOverviewCard title="Tasks Completed" value="256" change="+12.1%" icon={<CheckSquare className="text-aura-secondary" />} />
        <ProjectOverviewCard title="Team Members" value="8" change="+2 new" icon={<Users className="text-aura-secondary" />} />
        <ProjectOverviewCard title="Open Issues" value="3" change="-2.5%" isNegative />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
            <ProgressChart />
        </div>
        <div>
            <TasksList />
        </div>
      </div>
      
       <div>
         <TeamMembers />
      </div>
    </div>
  );
};

export default Dashboard;
