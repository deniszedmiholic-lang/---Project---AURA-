
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import AuraAiChat from './components/AuraAiChat';

const App: React.FC = () => {
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);

  return (
    <div className="flex h-screen bg-aura-background font-sans">
      <Sidebar onOpenAiChat={() => setIsAiChatOpen(true)} />
      <main className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <div className="flex-1 p-6 lg:p-8 overflow-y-auto">
          <Dashboard />
        </div>
      </main>
      <AuraAiChat isOpen={isAiChatOpen} onClose={() => setIsAiChatOpen(false)} />
    </div>
  );
};

export default App;
